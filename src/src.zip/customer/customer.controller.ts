import { Controller } from '@nestjs/common';

@Controller('customer')
export class CustomerController {}
