export enum Role {
  Admin = 'admin',
  Staff = 'staff',
  Cashier = 'cashier',
}
